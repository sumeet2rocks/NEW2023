<br />
<b>Notice</b>:  Undefined index: chatId in <b>/home/u111747160/domains/daynightonline.in/public_html/api/chatApi/autoChatInitiate.php</b> on line <b>3</b><br />
Auto login successfully