<br />
<b>Notice</b>:  Undefined index: chatId in <b>/home/u111747160/domains/daynightonline.in/public_html/api/chatApi/chatSend.php</b> on line <b>3</b><br />
<br />
<b>Notice</b>:  Undefined index: msg in <b>/home/u111747160/domains/daynightonline.in/public_html/api/chatApi/chatSend.php</b> on line <b>4</b><br />
chat not initiated