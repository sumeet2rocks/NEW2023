<br />
<b>Notice</b>:  Undefined index: chatId in <b>/home/u111747160/domains/daynightonline.in/public_html/api/chatApi/chatInitiat.php</b> on line <b>4</b><br />
_896