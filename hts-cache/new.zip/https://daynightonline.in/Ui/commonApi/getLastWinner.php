<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/commonApi/getLastWinner.php</b> on line <b>10</b><br />
[{"type":"First Full House","tno":"8","name":"Vernon","phone":"Vernon","booker":"admin"},{"type":"First Full House","tno":"","name":"","phone":"","booker":""},{"type":"First Full House","tno":"","name":"","phone":"","booker":""}]