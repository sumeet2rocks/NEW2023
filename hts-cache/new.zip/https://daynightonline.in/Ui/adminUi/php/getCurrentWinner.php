<br />
<b>Notice</b>:  Undefined offset: 2 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>12</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>12</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>16</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>16</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>22</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>22</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>23</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>23</b><br />
<br />
<b>Warning</b>:  fopen(../../../agentDb//name.txt): failed to open stream: No such file or directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>23</b><br />
<br />
<b>Warning</b>:  fread() expects parameter 1 to be resource, bool given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>23</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>24</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>24</b><br />
<br />
<b>Warning</b>:  fopen(../../../agentDb//phone.txt): failed to open stream: No such file or directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>24</b><br />
<br />
<b>Warning</b>:  fread() expects parameter 1 to be resource, bool given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>24</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>28</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>28</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>28</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>28</b><br />
<br />
<b>Notice</b>:  Undefined offset: 3 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>12</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>12</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>16</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>16</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>22</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>22</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>23</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>23</b><br />
<br />
<b>Warning</b>:  fopen(../../../agentDb//name.txt): failed to open stream: No such file or directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>23</b><br />
<br />
<b>Warning</b>:  fread() expects parameter 1 to be resource, bool given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>23</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>24</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>24</b><br />
<br />
<b>Warning</b>:  fopen(../../../agentDb//phone.txt): failed to open stream: No such file or directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>24</b><br />
<br />
<b>Warning</b>:  fread() expects parameter 1 to be resource, bool given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>24</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>28</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>28</b><br />
<br />
<b>Notice</b>:  Undefined index: tno: in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>28</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/getCurrentWinner.php</b> on line <b>28</b><br />
[{"type":"First Full House","tno":"","name":"","phone":"","booker":"","bookerPhone":""},{"type":"First Full House","tno":"","name":"","phone":"","booker":"","bookerPhone":""}]