<br />
<b>Notice</b>:  Undefined index: pass in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/adminUi/php/login.php</b> on line <b>3</b><br />
WRONG CREDENTIAL