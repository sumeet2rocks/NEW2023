<br />
<b>Notice</b>:  Undefined index: jsonName in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/agentUi/php/getJsonFile.php</b> on line <b>3</b><br />
<br />
<b>Warning</b>:  fopen(../../../gameData/.txt): failed to open stream: No such file or directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/agentUi/php/getJsonFile.php</b> on line <b>4</b><br />
<br />
<b>Warning</b>:  fread() expects parameter 1 to be resource, bool given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/agentUi/php/getJsonFile.php</b> on line <b>4</b><br />
null