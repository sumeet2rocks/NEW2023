<br />
<b>Notice</b>:  Undefined index: name in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/agentUi/php/login.php</b> on line <b>3</b><br />
<br />
<b>Notice</b>:  Undefined index: pass in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/agentUi/php/login.php</b> on line <b>4</b><br />
