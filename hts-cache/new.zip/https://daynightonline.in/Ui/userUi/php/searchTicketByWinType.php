<br />
<b>Notice</b>:  Undefined index: winType in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>4</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  fread(): read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  array_merge(): Expected parameter 1 to be an array, null given in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
<br />
<b>Notice</b>:  Undefined index: tno:0 in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
<br />
<b>Notice</b>:  Trying to access array offset on value of type null in <b>/home/u111747160/domains/daynightonline.in/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>173</b><br />
{"data":[{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null},{"TNO":"0","name":"","ticketRow":null}]}